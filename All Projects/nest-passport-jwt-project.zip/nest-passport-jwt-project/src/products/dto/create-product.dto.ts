export class CreateProductDto {
    id: number;
    name: string;
    description: string;

}
