export class AuthPayloadDto {

    name: string;
    password: string;
    address: string;
    email: string;
    role: string;
    isActive: boolean;
    
}